<?php


/* AWS Keys */
define( 'DBI_AWS_ACCESS_KEY_ID', 'AKIAJ24NBM43LC6REGCQ' );

define( 'DBI_AWS_SECRET_ACCESS_KEY', '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' );


define('DB_NAME', 'laserkart');
define('DB_USER', 'laserkart');
define('DB_PASSWORD', 'YRjw^4TrJVUZ%v@0aLr_~ozhQL9DB{Zx');

define('DB_HOST', 'localhost');
define('DB_CHARSET', 'utf8');
define('DB_COLLATE', '');

define('AUTH_KEY',         'ktKHevghSQQngFpiwzgDYlW8ApdTXyo3Cl60ZxzX');
define('SECURE_AUTH_KEY',  'R9b1GcqCuEUZRObO4zAN5YpYVNqR50Vs1eLp4aBz');
define('LOGGED_IN_KEY',    'uJwjQEwrXiNX23YdxmQTwwpbZsIgydPV6eFcRf18');
define('NONCE_KEY',        'jayDnubRGQquu2IEcUBKCFSWct9rjcrk6AVdFbYG');
define('AUTH_SALT',        'YlBjGGGf6Gbyp24V4gm5Rw1NEzwBV5yp68ZLIM4i');
define('SECURE_AUTH_SALT', 'ApHjI8JwXowRjjigyAums9hnqbAAgAtlkCRYGtr3');
define('LOGGED_IN_SALT',   'LggBK8Iw2v3wvVmiPmeBGODQKS9gXAtLof0BuYnn');
define('NONCE_SALT',       'rX4mKOdyY95fQDiFRbuMNTLnS200w65u3YeAvXai');

$table_prefix  = 'wp_';

define('SP_REQUEST_URL', ($_SERVER['HTTPS'] ? 'https://' : 'http://') . $_SERVER['HTTP_HOST']);

define('WP_SITEURL', 'http://laserkart.com');
define('WP_HOME', 'http://laserkart.com');

/* Change WP_MEMORY_LIMIT to increase the memory limit for public pages. */
define('WP_MEMORY_LIMIT', '256M');

/* Uncomment and change WP_MAX_MEMORY_LIMIT to increase the memory limit for admin pages. */
//define('WP_MAX_MEMORY_LIMIT', '256M');

/* That's all, stop editing! Happy blogging. */

if ( !defined('ABSPATH') )
        define('ABSPATH', dirname(__FILE__) . '/');

require_once(ABSPATH . 'wp-settings.php');
